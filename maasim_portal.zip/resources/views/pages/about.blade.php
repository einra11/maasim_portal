@extends('layouts.app')

@section('content')
<h1>About</h1>
        <p>Barangay Poblacion Maasim Web Information System solution that provides systematic approach in managing the residents profile, judicia information and enables document generation for effective planning and monitoring the barangay level</p>
        <about-app></about-app>
@endsection
