<footer class="footer navbar-static-top" style="background-color:#051C3B;">
    <div class="container text-center">
      <span class="text-muted">Barangay Maasim Portal <br/> Copyright © 2018. All Rights Reserved</span>
    </div>
  </footer>