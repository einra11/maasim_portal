<?php $__env->startSection('content'); ?>  
<div class="container">
    
        <div class="jumbotron">   
                        <h1>Welcome To <?php echo e($title); ?></h1>
                        <p>This is the official information website for the municipality of Maasim</p>
        </div>
        
        <div class="row featurette">
                        <div class="col-md-7">
                          <calendar-app></calendar-app>
                        </div>
                        <div class="col-md-5">
                          <clock-app class="right"></clock-app>
                          <img style="width:100%;" class="featurette-image img-fluid mx-auto" src="/storage/cover_images/headers/header-home.png" alt="Generic placeholder image">
                           <h2 class="featurette-heading">Maasim Municipality</h2>
                          <p class="lead">Donec ullamcorper nulla non metus auctor fringilla. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur. Fusce dapibus, tellus ac cursus commodo.</p>
                        </div>
                      </div>
        </div>
<?php $__env->stopSection(); ?>             
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>