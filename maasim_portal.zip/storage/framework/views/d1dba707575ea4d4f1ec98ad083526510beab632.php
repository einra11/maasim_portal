<?php $__env->startSection('content'); ?>
<div class="col-md-offset-0">
                <div class="panel panel-default">
                                <h1 class="panel-heading">Request Form</h1>
                                <div class="panel-body">
                                        <div class="form-row">
                                                <?php echo Form::open(['action' => 'RequestsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                                                <div class="form-group col-md-4">
                                                    <?php echo e(Form::label('lastname', 'Last Name')); ?>

                                                    <?php echo e(Form::text('lastname', '', ['class' => 'form-control', 'placeholder' => 'Last Name'])); ?>

                                                </div>
                                                <div class="form-group col-md-4">
                                                        <?php echo e(Form::label('firstname', 'First Name')); ?>

                                                        <?php echo e(Form::text('firstname', '', ['class' => 'form-control', 'placeholder' => 'First name'])); ?>

                                                </div>
                                                <div class="form-group col-md-4">
                                                        <?php echo e(Form::label('middlename', 'Middle Name')); ?>

                                                        <?php echo e(Form::text('middlename', '', ['class' => 'form-control', 'placeholder' => 'Middle name'])); ?>

                                                </div>
                                                <div class="form-group col-md-6">
                                                        <?php echo e(Form::label('email', 'Email Address')); ?>

                                                        <?php echo e(Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'example@gmail.com'])); ?>

                                                </div>
                                                <div class="form-group col-md-6">
                                                    <div class="col-md-3">
                                                            <?php echo e(Form::label('birthdate', 'Birth-Month')); ?>

                                                            <?php echo e(Form::selectMonth('month', '', ['class' => 'form-control'])); ?>

                                                    </div>
                                                    <div class="col-md-3">
                                                            <?php echo e(Form::label('birthdate', 'Birth-Day')); ?>

                                                            <?php echo e(Form::selectRange('day', 1, 31, '',['class' => 'form-control'])); ?>

                                                    </div>
                                                    <div class="col-md-3">
                                                            <?php echo e(Form::label('birthdate', 'Birth-Year')); ?>

                                                            <?php echo e(Form::selectRange('year', 2018, 1900, '',['class' => 'form-control'])); ?>

                                                    </div>
                                                    <div class="col-md-3">
                                                            <?php echo e(Form::label('gender', 'Gender')); ?>

                                                            <?php echo e(Form::select('gender', ['M' => 'Male', 'F' => 'Female'], '',['class'=>'form-control'])); ?>

                                                        </div>
                                                </div>
                                                <div class="form-group col-md-6">
                                                        <?php echo e(Form::label('contact', 'Cellphone No.')); ?>

                                                        <?php echo e(Form::text('contact', '', ['class' => 'form-control', 'placeholder' => '+639*******'])); ?>

                                                </div>
                                                <div class="form-group col-md-6">
                                                        <?php echo e(Form::label('request', 'Requested Items')); ?>

                                                        <br>
                                                        <div class="form-group col-md-3">
                                                                <?php echo e(Form::label('request', 'Barangay Certificate')); ?>

                                                                <?php echo e(Form::checkbox('requestP[]', 'Barangay Certificate')); ?>

                                                        </div>
                                                        <div class="form-group col-md-3">
                                                                <?php echo e(Form::label('request', 'Barangay Clearance')); ?>

                                                                <?php echo e(Form::checkbox('requestP[]', 'Barangay Clearance')); ?>

                                                        </div>
                                                        <div class="form-group col-md-3">
                                                                <?php echo e(Form::label('request', 'Notice of Hearing')); ?>

                                                                <?php echo e(Form::checkbox('requestP[]', 'Notice of Hearing')); ?>

                                                        </div>
                                                        <div class="form-group col-md-3">
                                                                <?php echo e(Form::label('request', 'IST Summons')); ?>

                                                                <?php echo e(Form::checkbox('requestP[]', 'IST Summons')); ?>

                                                        </div>
                                                </div>
                                                    <div class="form-group col-md-12">
                                                            <?php echo e(Form::label('purpose', 'Purpose')); ?>

                                                            <?php echo e(Form::textarea('purpose', '', ['class' => 'form-control', 'placeholder' => 'purpose...'])); ?>

                                                    </div>
                                                    <div class="form-group col-md-6">
                                                            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

                                                    </div>
                                                    
                                            <?php echo Form::close(); ?>

                                        </div>
                                </div>
                        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>