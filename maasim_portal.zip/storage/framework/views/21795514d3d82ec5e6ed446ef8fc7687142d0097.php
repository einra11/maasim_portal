<?php $__env->startSection('content'); ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <main-app></main-app>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>