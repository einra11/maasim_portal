<?php $__env->startSection('content'); ?>
<div class="row featurette">
    <div class="col-md-7">
    <a href="/announcements" class="btn btn-default">Go back</a>
    <?php if(!Auth::guest()): ?>
    <a href="/announcements/<?php echo e($post->id); ?>/edit" class="btn btn-default">Edit</a>
        <?php if(Auth::user()->id == $post->user_id): ?>
            <?php echo Form::open(['action'=>['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method','DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class'=>'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
    <div class="panel panel-default">
            <h2 class="panel-heading"><?php echo e($post->annc_title); ?></h2>
            <div class="panel-body">
                    <p class="lead text-justify"><?php echo $post->annc_content; ?></p>
                    <hr class="featurette-divider">
                    <small>Posted on <?php echo e($post->created_at); ?></small>
            </div>
    </div>
    </div>
    <div class="col-md-5">
      <img style="width:100%" class="featurette-image img-fluid mx-auto" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="Generic placeholder image">
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>